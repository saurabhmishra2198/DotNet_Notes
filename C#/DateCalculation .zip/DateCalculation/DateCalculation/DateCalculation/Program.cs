﻿using System;
using System.Security;

namespace DateCalculation
{
    internal class Program
    {
        //DateCalucaltion function
        public static void GetNextRunDate(int? day, DateTime? currentDate)
        {
            DateTime dateTime = Convert.ToDateTime(currentDate);

            int? CurrentDays = dateTime.Day;
            int? Totaldays = DateTime.DaysInMonth(dateTime.Year, dateTime.Month);

            int? Reaming = (day <= CurrentDays) ? (Totaldays - CurrentDays) + day : day - CurrentDays;

            Console.WriteLine("\nNext Run Date: " + dateTime.Date.AddDays(Convert.ToDouble(Reaming)).ToLongDateString());

            //if (CurrentDays==day)
            //{
            //    Console.WriteLine("\nNext Run Date: " + dateTime.Date.AddMonths(1).ToLongDateString());
            //}
            //else if (CurrentDays > day)
            //{
            //    int? ReamingDays = Totaldays - CurrentDays + day;
            //    Console.WriteLine("\nNext Run Date: " + dateTime.Date.AddDays(Convert.ToDouble(ReamingDays)).ToLongDateString());
            //}
            //else
            //{
            //    int? ComapireDay = day - CurrentDays;
            //    Console.WriteLine("\nNext Run Date: " + dateTime.Date.AddDays(Convert.ToDouble(ComapireDay)).ToLongDateString());
            //}
        }
        static void Main(string[] args)
        {
            //Take days from the user
            while (true)
            {
                Console.Write("\nEnter day:");
                int day = Convert.ToInt32(Console.ReadLine());
                if(day <= 0 || day > 31)
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine("\nInvalid day!,Enter day between 1 and 31.");
                }
                else
                {
                    Console.ForegroundColor = ConsoleColor.Yellow;
                    GetNextRunDate(day, DateTime.Now.Date);
                }
                Console.ForegroundColor = ConsoleColor.Gray;
            }
            

            //Take Date from user and Perform on User date
            //Console.Write("Enter date (dd/month/yyyy):");
            //DateTime dateTime = Convert.ToDateTime(Console.ReadLine());

            //GetNextRunDate(day, dateTime.Date);

            //Current date Call
            //GetNextRunDate(day, DateTime.Now.Date);
        }
    }
}